import pandas as pd

tea_file1 =r'C:\Users\guoch\PycharmProjects\SurveyProcessor\Week1 data\教学反馈习惯与需求调查（教师版）  Teacher Survey on Teaching Feedback Habits and Needs(1-3).xlsx'
tea_file2 =r'C:\Users\guoch\PycharmProjects\SurveyProcessor\Week1 data\321310034_按文本_教学反馈习惯与需求调查（教师版）_8_8.xlsx'


tea_replacement_map = {

    '期末教学评价问卷': '期末教学评价问卷 / Course-end surveys',
    '课堂即时反馈工具（如 Mentimeter 等）': '课堂即时反馈工具（如 Mentimeter 等） / Real-time classroom feedback tools (e.g., Mentimeter)',
    '匿名意见箱（线上或线下）': '匿名意见箱（线上或线下） / Anonymous suggestion boxes (online/offline)',
    '微信/QQ群/WhatsApp': '微信/QQ群/WhatsApp / WeChat/QQ/WhatsApp',
    '班委/代表反馈': '班委/代表反馈 / Teaching assistants or class representatives',
    '面对面交流': '面对面交流 / Face-to-face talks',
    '邮件': '邮件 / Email',
    '学习管理系统留言（如 Canvas、Blackboard）': '学习管理系统留言（如 Canvas、Blackboard） / Learning management system messages (e.g., Canvas, Blackboard)',
    '其他（请说明）': '其他（请说明） / Others (please specify) ',


    '非常有效': '非常有效 / Very effective',
    '比较有效': '比较有效 / Quite effective',
    '一般': '一般 / Neutral',
    '不太有效': '不太有效 / Not very effective',
    '无效': '无效 / Not effective at all',


    '非常同意': '非常同意 / Strongly agree',
    '同意': '同意 / Agree',
    '一般': '一般 / Neutral',
    '不同意': '不同意 / Disagree',
    '非常不同意': '非常不同意 / Strongly disagree',


    '经常': '经常 / Often',
    '有时': '有时 / Sometimes',
    '很少': '很少 / Rarely',
    '几乎不读': '几乎不读 / Almost never',


    '经常': '经常 / Often',
    '偶尔': '偶尔 / Occasionally',
    '很少': '很少 / Rarely',
    '从未': '从未 / Never',


    '总是': '总是 / Always',
    '大多数时候': '大多数时候 / Most of the time',
    '偶尔': '偶尔 / Occasionally',
    '很少': '很少 / Rarely',
    '从不': '从不 / Never',


    '经常使用': '经常使用 / Frequently',
    '偶尔使用': '偶尔使用 / Occasionally',
    '了解但未使用': '了解但未使用 / Know about them but never used',
    '未了解': '未了解 / Not aware of them',


    '非常有帮助': '非常有帮助 / Very helpful',
    '有一定帮助': '有一定帮助 / Somewhat helpful',
    '一般': '一般 / Neutral',
    '没有帮助': '没有帮助 / Not helpful',
    '不确定': '不确定 / Not sure',


    '渠道不方便': '渠道不方便 / Feedback channels are inconvenient',
    '担心被识别': '担心被识别 / Fear of being identified',
    '不知道如何反馈': '不知道如何反馈 / Don’t know how to give feedback',
    '反馈不被重视': '反馈不被重视 / Feel their feedback is ignored',
    '时间不足': '时间不足 / Lack of time',
    '其他（请说明）': '其他（请说明） / Others (please specify) ',


    '情感倾向分析': '情感倾向分析 / Sentiment analysis',
    '关键词提取': '关键词提取 / Keyword extraction',
    '可视化趋势展示': '可视化趋势展示 / Visual trend displays',
    '按班级、时间、模块筛选': '按班级、时间、模块筛选 / Filtering by class, time, course module, etc.',
    '自动生成总结报告': '自动生成总结报告 / Automatic summary reports',
    '其他（请说明）': '其他（请说明） / Others (please specify) ',


    '每次作业后': '每次作业后 / After every assignment',
    '每月一次': '每月一次 / Once a month',
    '期中和期末各一次': '期中和期末各一次 / Midterm and final each once',
    '仅期末一次': '仅期末一次 / Only at the end of term',
    '其他（请说明）': '其他（请说明） / Others (please specify) ',

}



def translate_cell(cell):
    # If the cell is empty, return it as is
    if pd.isna(cell):
        return cell

    # If the cell is a string, check for separators (semicolon or newline)
    if isinstance(cell, str):
        separators = [';', '\n']
        for sep in separators:
            if sep in cell:
                # Split the string by the separator, strip spaces, translate each part, then join back with the separator
                parts = [part.strip() for part in cell.split(sep)]
                translated_parts = [tea_replacement_map.get(part, part) for part in parts]
                return sep.join(translated_parts)

    # Translate single values directly, if not found keep the original value
    return tea_replacement_map.get(str(cell).strip(), str(cell).strip())


def translate_excel(input_path, output_path):
    # Read the Excel file
    df = pd.read_excel(input_path)
    # Apply the translation function to each cell
    df_translated = df.applymap(translate_cell)
    # Save the translated Excel file without the index column
    df_translated.to_excel(output_path, index=False)
    print(f"✅ Translation completed and saved to: {output_path}")


# Read two Excel files
df1 = pd.read_excel(tea_file1)
df2 = pd.read_excel(tea_file2)

# Translate the contents of the second file
df2_translated = df2.map(translate_cell)

# Merge the two DataFrames by rows, resetting the index
merged_df = pd.concat([df1, df2_translated], ignore_index=True)

# Save the merged result to a new Excel file
merged_df.to_excel('tea_merged_data.xlsx', index=False)