import pandas as pd

stu_file1 = r'C:\Users\guoch\PycharmProjects\SurveyProcessor\Week1 data\教学反馈习惯与需求调查（学生版）_Student Survey on Teaching Feedback Habits and Needs(1-4).xlsx'
stu_file2 = r'C:\Users\guoch\PycharmProjects\SurveyProcessor\Week1 data\321311881_按文本_教学反馈习惯与需求调查（学生版）_4_4.xlsx'

stu_replacement_map = {
    '从不': '从不 / Never',
    '1–2': '1–2 次 / 1–2 times',
    '3 次以上': '3 次以上 / 3 times or more',

    '问卷': '问卷 / Questionnaires',
    '作业评论区': '作业评论区 / Assignment comment sections',
    '教学邮件、短信': '教学邮件、短信 / Teaching emails, messages',
    '课堂即时反馈工具': '课堂即时反馈工具 / Real-time classroom feedback tools',
    '其他（请注明）': '其他（请注明） / Others (please specify)',
    '其他（请说明）': '其他（请说明） / Others (please specify)',

    '是': '是 / Yes',
    '否': '否 / No',
    '不确定': '不确定 / Unsure',

    '经常有': '经常有 / Often',
    '偶尔有': '偶尔有 / Occasionally',
    '几乎没有': '几乎没有 / Rarely',
    '完全没有': '完全没有 / Never',

    '自由文本': '自由文本 / Free text',
    '选择题打分': '选择题打分 / Multiple choice for rating',
    '两者结合': '两者结合 / Combination of both',
    '不愿表达': '不愿表达 / Prefer not to express',

    '非常愿意': '非常愿意 / Very willing',
    '一般': '一般 / Somewhat willing',
    '不愿意': '不愿意 / Unwilling',
    '比较愿意': '比较愿意 / Somewhat willing',

    '反馈情感趋势图（正负面占比）': '反馈情感趋势图（正负面占比） / Feedback sentiment trend chart (positive/negative ratio)',
    '热门问题突出显示（词云）': '热门问题突出显示（词云） / Popular issue highlighted (Word Cloud)',
    '教师回应区': '教师回应区 / Teacher response section',
    '自己的反馈记录': '自己的反馈记录 / Personal feedback history',
    '全班反馈概况': '全班反馈概况 / Overall class feedback overview',

    '课程结束问卷': '课程结束问卷 / Course-end surveys',
    '课堂即时反馈工具（如 Mentimeter、钉钉投票）': '课堂即时反馈工具（如 Mentimeter、钉钉投票） / Real-time classroom feedback tools (e.g., Mentimeter, DingTalk polls)',
    '匿名意见箱（线上/线下）': '匿名意见箱（线上/线下） / Anonymous suggestion boxes (online/offline)',
    '微信、QQ群等': '微信、QQ群等 / WhatsApp groups etc.',
    '班委转达': '班委转达 / Class representative relay',
    '课后面谈': '课后面谈 / After-class face-to-face talks',
    '邮件反馈': '邮件反馈 / Email feedback',
    '学习管理系统留言（如 Canvas/Blackboard）': '学习管理系统留言（如 Canvas/Blackboard） / Learning management system messages (e.g., Canvas, Blackboard)',

    '非常方便': '非常方便 / Very convenient',
    '不太方便': '不太方便 / Not very convenient',
    '非常不方便': '非常不方便 / Very inconvenient',

    '意见没人看': '意见没人看 / Feedback is ignored',
    '写反馈太麻烦': '写反馈太麻烦 / Too much effort to write feedback',
    '不知道怎么反馈': '不知道怎么反馈 / Don\'t know how or where to give feedback',
    '工具不好用': '工具不好用 / Tools are not user-friendly',
    '缺乏匿名性': '缺乏匿名性 / Lack of anonymity',
    '不知道有没有回应': '不知道有没有回应 / No idea whether feedback is noticed/responded to',
    '不清楚反馈目的': '不清楚反馈目的 / Don\'t understand the purpose of feedback',

    '经常写': '经常写 / Often',
    '偶尔写': '偶尔写 / Occasionally',
    '很少写': '很少写 / Rarely',
    '从不写': '从不写 / Never',

    '会': '会 / Yes',
    '可能会': '可能会 / Probably yes',
    '不太可能': '不太可能 / Probably no',
    '不会': '不会 / No',

    '报告形式': '报告形式 / Reports',
    '图表展示': '图表展示 / Charts & graphs',
    '趋势分析': '趋势分析 / Trend analysis',
    '简要总结': '简要总结 / Brief summaries',

    '您觉得反馈系统最需要改进的地方是什么？': '您觉得反馈系统最需要改进的地方是什么？ / What do you think is the most important improvement needed in the feedback system?',
    '请您提出对教学反馈系统或流程的建议或意见。': '请您提出对教学反馈系统或流程的建议或意见。 / Please provide any suggestions or comments you have regarding the teaching feedback system or process.',
}


def translate_cell(cell):
    # If the cell is empty, return it as is
    if pd.isna(cell):
        return cell

    # If the cell is a string, check for separators (semicolon or newline)
    if isinstance(cell, str):
        separators = [';', '\n']
        for sep in separators:
            if sep in cell:
                # Split the string by the separator, strip spaces, translate each part, then join back with the separator
                parts = [part.strip() for part in cell.split(sep)]
                translated_parts = [stu_replacement_map.get(part, part) for part in parts]
                return sep.join(translated_parts)

    # Translate single values directly, if not found keep the original value
    return stu_replacement_map.get(str(cell).strip(), str(cell).strip())


def translate_excel(input_path, output_path):
    # Read the Excel file
    df = pd.read_excel(input_path)
    # Apply the translation function to each cell
    df_translated = df.applymap(translate_cell)
    # Save the translated Excel file without the index column
    df_translated.to_excel(output_path, index=False)
    print(f"✅ Translation completed and saved to: {output_path}")


# Read two Excel files
df1 = pd.read_excel(stu_file1)
df2 = pd.read_excel(stu_file2)

# Translate the contents of the second file
df2_translated = df2.map(translate_cell)

# Merge the two DataFrames by rows, resetting the index
merged_df = pd.concat([df1, df2_translated], ignore_index=True)

# Save the merged result to a new Excel file
merged_df.to_excel('stu_merged_data.xlsx', index=False)
