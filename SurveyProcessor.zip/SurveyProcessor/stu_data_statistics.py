import pandas as pd
from collections import Counter

file_path = r'C:\Users\guoch\PycharmProjects\SurveyProcessor\stu_merged_data.xlsx'  # Excel file path
df = pd.read_excel(file_path)  # Read Excel file into DataFrame

# Questions that only print answers without counting
no_count_questions = [
    "您觉得反馈系统最需要改进的地方是什么？ / What do you think is the most important improvement needed in the feedback system? ",
    "请您提出对教学反馈系统或流程的建议或意见。 / Please provide any suggestions or comments you have regarding the teaching feedback system or process. "
]


def is_valid_answer(ans):
    """Check if the answer is valid (not '(空)' after stripping whitespace)"""
    ans = ans.strip()
    return ans !='' and ans != "(空)"


def count_answers(series):
    """Count occurrences of answers in a series, handle multi-choice by splitting on ';'"""
    all_answers = []
    for cell in series.dropna():
        cell_str = str(cell).strip()
        if not is_valid_answer(cell_str):
            continue
        if ';' in cell_str:
            answers = [ans.strip() for ans in cell_str.split(';') if is_valid_answer(ans)]
            all_answers.extend(answers)
        else:
            all_answers.append(cell_str)
    return Counter(all_answers)


# Count total participants based on first question column's valid responses
first_col = df.columns[0]
valid_responses = df[first_col].dropna().map(str).apply(is_valid_answer)
num_participants = valid_responses.sum()
print(f"Total participants: {num_participants}")

# Iterate through each question (column) and print results and plot pie charts
for col in df.columns:
    print(f"\nQuestion: {col}")
    if col in no_count_questions:
        # For these questions, just print all valid answers without counting
        answers = [ans.strip() for ans in df[col].dropna().map(str).tolist() if is_valid_answer(ans)]
        for ans in answers:
            print(ans)
    else:
        # For other questions, count and print answer frequencies
        counter = count_answers(df[col])

        for ans, cnt in counter.most_common():
            print(f"{ans}: {cnt}")





